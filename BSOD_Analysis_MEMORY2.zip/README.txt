BSOD ANALYZER - EXTRACTED DATA
==============================

This ZIP file contains extracted diagnostic data from a Windows memory dump file.
The data was extracted using the BSOD Analyzer Parser Tool.

FILES INCLUDED:
---------------
- analysis.json      : Complete analysis in JSON format (for upload to BSOD Analyzer website)
- summary.txt        : Human-readable summary of the crash
- system_info.json   : System information (OS version, architecture, etc.)
- crash_summary.json : Basic crash information (bugcheck code and parameters)
- bugcheck_analysis.json : Detailed bugcheck interpretation
- stack_trace.json   : CPU register state and exception info (if available)
- drivers.json       : List of loaded drivers (if extractable)

HOW TO USE:
-----------
1. Upload the 'analysis.json' file to the BSOD Analyzer website for AI-powered analysis
2. The AI will provide detailed explanations and troubleshooting recommendations
3. Review the 'summary.txt' file for a quick human-readable overview

PRIVACY NOTE:
-------------
This extracted data contains ONLY diagnostic information.
- NO personal files or data are included
- NO passwords or credentials are included
- NO browsing history or personal content is included
- Only technical crash information is extracted

The original dump file is NOT included in this ZIP.

For questions or support, visit the BSOD Analyzer website.
